package cl.aracridav.svua.inventario.historial.dto.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class HistorialActivoResponse {

    private LocalDateTime fecha;
    private LocalDateTime fechaProgramada;
    private LocalDateTime fechaEjecucion;
    private String tipo;
    private String descripcion;
    private String usuario;
    private String proveedor;
    private BigDecimal costoTotal;
    private BigDecimal valorHora;
    private BigDecimal costoManoObra;
    private BigDecimal horasTrabajo;

    private List<String> repuestos;
}
