package cl.aracridav.svua.inventario.activo.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import cl.aracridav.svua.inventario.activo.entity.Activo;
import cl.aracridav.svua.shared.enums.EstadoActivo;

public interface ActivoRepository extends JpaRepository<Activo, Long> {

    boolean existsByCodigoInterno(String codigoInterno);

    @Query("""
        SELECT a FROM Activo a
        WHERE a.estadoActual = :estado
    """)
    List<Activo> findByEstado(@Param("estado") String estado);

    @Query("""
        SELECT a FROM Activo a
        WHERE a.fechaBaja IS NULL
    """)
    List<Activo> findActivosOperativos();

    @Query("""
        SELECT a FROM Activo a
        WHERE a.ubicacion = :idUbicacion
    """)
    List<Activo> findByUbicacion(@Param("idUbicacion") Long idUbicacion);

    Long countByEmpresaId(Long empresaId);

    Long countByEmpresaIdAndEstadoActual(Long empresaId, EstadoActivo estado);

    @Query("""
        SELECT COALESCE(SUM(a.valorAdquisicion),0)
        FROM Activo a
        WHERE a.empresa.id = :empresaId
    """)
    BigDecimal sumValorByEmpresa(@Param("empresaId") Long empresaId);

    Optional<Activo> findFirstByNombre(String nombre);

    Optional<Activo> findByNombreContainingIgnoreCase(String nombre);

    @Query("""
        SELECT DISTINCT a
        FROM Activo a
        LEFT JOIN FETCH a.historialEstados he
        LEFT JOIN FETCH he.usuario
        LEFT JOIN FETCH a.ordenesMantenimiento om
        LEFT JOIN FETCH om.usuario
        LEFT JOIN FETCH om.proveedor
        LEFT JOIN FETCH om.repuestosUtilizados ru
        LEFT JOIN FETCH ru.repuesto
        """)
    List<Activo> findAllConHistorial();

    @Query("""
        SELECT DISTINCT a
        FROM Activo a
        LEFT JOIN FETCH a.historialEstados he
        LEFT JOIN FETCH he.usuario
        LEFT JOIN FETCH a.ordenesMantenimiento om
        LEFT JOIN FETCH om.usuario
        LEFT JOIN FETCH om.proveedor
        WHERE a.empresa.id = :empresaId
    """)
    List<Activo> findAllConHistorialByEmpresa(
        @Param("empresaId") Long empresaId
    );

    Optional<Activo> findFirstByNombreAndEmpresaId(
        String nombre,
        Long empresaId
    );

    List<Activo> findByEmpresaId(Long empresaId);
}
